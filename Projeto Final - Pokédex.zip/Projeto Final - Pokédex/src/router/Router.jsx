import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Pag1 from '../pages/Pag1';
import Pag2 from "../pages/Pag2";

export const Router = () => {
    return (
        <BrowserRouter>
            <Routes>
                <Route path='/' element={<Pag1/>}/>
                <Route path='/pag2' element={<Pag2/>}/>
            </Routes>
        </BrowserRouter>
    );
}
